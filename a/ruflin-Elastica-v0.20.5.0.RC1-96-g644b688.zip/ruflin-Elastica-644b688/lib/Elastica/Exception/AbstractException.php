<?php

namespace Elastica\Exception;

/**
 * Abstract general Elastica exception object
 *
 * @category Xodoa
 * @package Elastica
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
abstract class AbstractException extends \Exception
{
}
