<?php

namespace Elastica\Exception;

class BulkException extends AbstractException
{
}
